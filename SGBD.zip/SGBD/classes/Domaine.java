package RandyDataBases;

import java.io.Serializable;

/**
 * Domaine
 */
public class Domaine  implements Serializable{

    public Domaine(Object typeAttribut, int size)  {
        this.typeAttribut = typeAttribut;
        this.size = size;
    }
    private Object typeAttribut;
    public Object getTypeAttribut() {
        return typeAttribut;
    }
    public void setTypeAttribut(Object typeAttribut) {
        this.typeAttribut = typeAttribut;
    }
    public int size;
    public int getSize() {
        return size;
    }
    public void setSize(int size) {
        this.size = size;
    }
}