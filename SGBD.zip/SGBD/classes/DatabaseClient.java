package Net;

import java.io.*;
import java.net.*;
import java.util.ArrayList;

import Net.ConfigReader;

public class DatabaseClient {
    public static void main(String[] args) {
        Object[] config = ConfigReader.readConfig();
        int port = 0;
        String host = "";
        if(config[1] instanceof Integer){
            port = (int) config[1];
        }
        if(config[0] instanceof String){
            host = (String)config[0];
        }

        BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Connected to [RandySQL]");
        while (true) {
        try (Socket socket = new Socket(host, port);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             ) {
    
            System.out.print("[RandySQL] -- > ");
    
            String userInput;
                userInput = consoleInput.readLine();
                if(userInput.equalsIgnoreCase("quit")){break;}
                out.println(userInput);  
    
                try (ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream())) {
                    Object objet = objectInputStream.readObject();
                    if(objet instanceof ArrayList<?>){
                        @SuppressWarnings("unchecked")
                        ArrayList<Object> obj = (ArrayList<Object>) objet;
                        for (Object o : obj) {
                            System.out.println("[RandySQL] -- > "+ o);
                        }
                        System.out.println("[RandySQL] -- > "+obj.size()+" ligne(s) selectionné(e)s");
                    }
                } catch (ClassNotFoundException | IOException e) {
                    System.out.println("[RandySQL] -- > "+ e.getMessage());
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    
}


