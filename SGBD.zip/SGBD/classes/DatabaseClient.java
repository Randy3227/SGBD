package Net;

import java.io.*;
import java.net.*;
import java.util.ArrayList;

import Net.ConfigReader;

public class DatabaseClient {

    private static final String RESET = "\u001B[0m";
    private static final String RED = "\u001B[31m";
    private static final String GREEN = "\u001B[32m";
    private static final String YELLOW = "\u001B[33m";
    private static final String BLUE = "\u001B[34m";
    private static final String CYAN = "\u001B[36m";
    public static void main(String[] args) {
        Object[] config = ConfigReader.readConfig();
        int port = 0;
        String host = "";
        if(config[1] instanceof Integer){
            port = (int) config[1];
        }
        if(config[0] instanceof String){
            host = (String)config[0];
        }

        BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in));
        System.out.println(GREEN +"Connected to [RandySQL]");
        while (true) {
        try (Socket socket = new Socket(host, port);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             ) {
    
            System.out.print(BLUE +"[RandySQL] -- > ");
    
            String userInput;
                userInput = consoleInput.readLine();
                if(userInput.equalsIgnoreCase("quit")){break;}
                out.println(userInput);  
    
                try (ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream())) {
                    Object objet = objectInputStream.readObject();
                    if(objet instanceof ArrayList<?>){
                        @SuppressWarnings("unchecked")
                        ArrayList<Object> obj = (ArrayList<Object>) objet;
                        for (Object o : obj) {
                            System.out.println(CYAN+"[RandySQL] -- > "+ o);
                        }
                        System.out.println(YELLOW + "[RandySQL] -- > "+obj.size()+" ligne(s) selectionné(e)s");
                    }
                } catch (ClassNotFoundException | IOException e) {
                    System.out.println(RED +"[RandySQL] -- > "+ e.getMessage());
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    
}


