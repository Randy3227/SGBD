package RandyDataBases;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;



/**
 * Operateur
 */
public final class Operateur  implements Serializable{  
    public static int compare(Object o1, Object o2) throws Exception {
        if (o1 instanceof Integer && o2 instanceof Integer) {
            return Integer.compare((Integer) o1, (Integer) o2);
        } else if (o1 instanceof Double && o2 instanceof Double) {
            return Double.compare((Double) o1, (Double) o2);
        } else if (o1 instanceof String && o2 instanceof String) {
            return ((String) o1).compareTo((String) o2);
        } else if (o1 instanceof Date && o2 instanceof Date) {
            return ((Date) o1).compareTo((Date) o2);
        } else {
            throw new Exception("Types incompatibles pour la comparaison : " + o1.getClass() + " et " + o2.getClass());
        }
    }
    // compare() > 0 --> a > b
    // compare() < 0 --> a < b
    // comare() =0   --< a = b 
    
    public static ArrayList<Object> union(ArrayList<Object> entite1,ArrayList<Object> entite2) {
        ArrayList<Object> result = new ArrayList<>(entite1);
        for (Object e2 : entite2) {
            if (!result.contains(e2)) {
                result.add(e2);
            }
        }
        return result;
    }
    

    public static ArrayList<Object> intersection(ArrayList<Object> entite1,ArrayList<Object> entite2) {
        ArrayList<Object> result = new ArrayList<>();
        for (Object e1 : entite1) {
            if(entite2.contains(e1)){
                result.add(e1);
            }
        }
        return result;
    }

    public static ArrayList<Object> privation(ArrayList<Object> entite1,ArrayList<Object> entite2){
        ArrayList<Object> priv = new ArrayList<>(entite1);
        ArrayList<Object> result = new ArrayList<>();
        priv.removeAll(entite2);
        for (Object obj : priv) {
            if(!result.contains(obj))
                result.add(obj);
        }
        return result;
    }

    public static Entite newEntiteByCartesien(Entite principal,Entite autre)throws Exception{
        ArrayList<Attributs> newAttributs = principal.getAttributs();
        for (Attributs att : autre.getAttributs()) {
            newAttributs.add(att);
        }
        return new Entite("cartesien",newAttributs);
    }
    public static Entite createNewEntiteByCartesein(Entite principal,Entite autre,String thisAttribut,String autreAttribut)throws Exception{
         ArrayList<ArrayList<Object>> cartesien = principal.produitCartesien(autre);
         Entite news = newEntiteByCartesien(principal,autre);
        try {
            if(principal.checkIfAttributExist(principal,thisAttribut)==null)
                throw new Exception("La table "+principal.getNomEntite()+" ne contient pas la colonne "+thisAttribut);
            
            if(autre.checkIfAttributExist(autre,autreAttribut)==null)
                throw new Exception("La table "+autre.getNomEntite()+" ne contient pas la colonne "+autreAttribut);
            
            if(principal.checkIfAttributExist(principal,thisAttribut)!=null && autre.checkIfAttributExist(autre,autreAttribut)!=null){
                for (int index = 0; index < news.getAttributs().size(); index++){
                    ArrayList<Nuplets> nuplets = new ArrayList<>();
                    for (ArrayList<Object> cart: cartesien) {
                        nuplets.add(new Nuplets(cart.get(index)));
                    }
                    news.getAttributs().get(index).setColonne(nuplets);
                }
            }
        }catch (Exception e) {
                e.printStackTrace();
        }
        return news;
    }   
    public static ArrayList<Integer> indexForJoin(Entite principal,Entite othr,String thisAttribut, String otherAttribut, String operation) throws Exception {
        ArrayList<Integer> indices = new ArrayList<>();
        try{
        Attributs att = principal.checkIfAttributExist(principal,thisAttribut); 
        Attributs other = othr.checkIfAttributExist(othr,otherAttribut);
        if (att != null && other!= null) {
            for (int i = 0; i < att.getColonne().size(); i++) {
                Object colonneForThis = att.getColonne().get(i).getValeur();
                Object colonneForOther = other.getColonne().get(i).getValeur();
                boolean condition = false;
                switch (operation) {
                    case "<":
                        condition = Operateur.compare(colonneForThis, colonneForOther) < 0;
                        break;
                    case "<=":
                        condition = Operateur.compare(colonneForThis, colonneForOther) <= 0;
                        break;
                    case ">":
                        condition = Operateur.compare(colonneForThis, colonneForOther) > 0;
                        break;
                    case ">=":
                        condition = Operateur.compare(colonneForThis, colonneForOther) >= 0;
                        break;
                    case "==":
                    case "=":
                        condition = colonneForThis.equals(colonneForOther);
                        break;
                    case "!=":
                        condition = !colonneForThis.equals(colonneForOther);
                        break;
                    default:
                        throw new Exception("Operation " + operation + " invalide");
                }
    
                if (condition) {
                    indices.add(i);
                }
            }
            if (att == null || other == null) 
                throw new Exception("aucun resultat");
        } else {
            throw new Exception("Attribut " + thisAttribut + " invalide");
        }
    }catch(Exception e){
        e.printStackTrace();
    }
        return indices;
    }
    
    public static ArrayList<Object> jointure(Entite principal,Entite autre,String thisAttribut,String autreAttribut,String operation)throws Exception{
        
        ArrayList<Object> all = new ArrayList<>();
        try {
            Entite nouveauEntite = createNewEntiteByCartesein(principal,autre, thisAttribut, autreAttribut);
            ArrayList<Integer> index = indexForJoin(principal,autre,thisAttribut, autreAttribut, operation);
            for (Integer i : index) {
                    all.add(Individu.getIndividu(nouveauEntite, i));
                }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        return all;
        
    }
 
}