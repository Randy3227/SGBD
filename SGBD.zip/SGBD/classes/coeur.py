import turtle

t = turtle.Turtle()
screen = turtle.Screen()
screen.bgcolor("white")

t.shape("turtle")
t.speed(3)

t.color("red")
t.begin_fill()
t.left(50)
t.forward(133)
t.circle(50, 200)
t.right(140)
t.circle(50, 200)
t.forward(133)
t.end_fill()

t.penup() 
t.goto(0, 60) 
t.color("white")  
t.write("Tsiory", align="center", font=("Arial", 24, "bold"))

t.hideturtle()

turtle.done()
