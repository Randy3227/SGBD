package RandyDataBases;
/**
 * DataBase
 */
import java.util.ArrayList;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
public class DataBase  implements Serializable{

    private String dbName;
    private ArrayList<Entite> tables = new ArrayList<Entite>();

    public DataBase(String dbName, ArrayList<Entite> tables) {
        this.dbName = dbName;
        this.tables = tables;
    
    }

    public Entite getEntiteByNom(String tableName){
        for (Entite entite : this.tables) {
            if(entite.getNomEntite().equalsIgnoreCase(tableName))
                return entite;
        }
        return null;
    }
    public String getDbName() {
        return dbName;
    }
    public void setDbName(String dbName) {
        this.dbName = dbName;
    }
    public ArrayList<Entite> getTables() {
        return tables;
    }
    public void setTables(ArrayList<Entite> tables) {
        this.tables = tables;
    }
    public void createTable(String tableName,ArrayList<Attributs> att){
        tables.add(new Entite(tableName,att));
    }
    public void dropTable(String tableName) throws Exception {
        boolean tableFound = false;

        for (int i = 0; i < tables.size(); i++) {
            if (tables.get(i).getNomEntite().equalsIgnoreCase(tableName)) {
                tables.remove(i);
                tableFound = true;
                break;
            }
        }

        if (!tableFound) {
            throw new Exception("Table \"" + tableName + "\" introuvable dans la base de données.");
        }
    }


  
} 