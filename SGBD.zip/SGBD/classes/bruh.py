import secrets
bruh = secrets.token_hex(100000000)
print(bruh)



