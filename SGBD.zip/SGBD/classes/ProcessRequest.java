package RandyDataBases;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import Net.*;

import RandyDataBases.Attributs;
import RandyDataBases.DataBase;
import RandyDataBases.Entite;
import RandyDataBases.Nuplets;

public final class ProcessRequest {
    public static String getEntite(String main) {
        String[] splited = main.split(" ");
        String entity = "";
        for (int i = 0; i < splited.length; i++) {
            if (splited[i].equalsIgnoreCase("from")) {
                entity = splited[i + 1];
            }
        }
        return entity;
    }

    public static ArrayList<String> getColonne(String main) {
        String[] splited = main.split(" ");
        ArrayList<String> result = new ArrayList<>();
        for (int i = 0; i < splited.length; i++) {
            if (splited[i].equalsIgnoreCase("select"))
                result.add(splited[i + 1]);
            if (splited[i].equals("/"))
                result.add(splited[i + 1]);
        }
        return result;
    }

    public static ArrayList<String> getValeur(String main) {
        ArrayList<String> operateur = new ArrayList<>(List.of("<", ">", "<=", ">=", "==", "=", "!="));
        String[] splited = main.split(" ");
        ArrayList<String> result = new ArrayList<>();
        for (int i = 0; i < splited.length; i++) {
            for (String string : operateur) {
                if (splited[i].equalsIgnoreCase(string)) {
                    result.add(splited[i + 1]);
                }
            }
        }
        return result;
    }

    public static ArrayList<String> getOperateur(String main) {
        ArrayList<String> operateur = new ArrayList<>(List.of("<", ">", "<=", ">=", "==", "=", "!="));
        ArrayList<String> result = new ArrayList<>();
        String[] splited = main.split(" ");
        for (int i = 0; i < splited.length; i++) {
            for (String string : operateur) {
                if (splited[i].equalsIgnoreCase(string)) {
                    result.add(splited[i]);
                }
            }
        }
        return result;
    }

    public static ArrayList<String> getColonneDesConditions(String main) {
        ArrayList<String> operateur = new ArrayList<>(List.of("<", ">", "<=", ">=", "==", "=", "!="));
        ArrayList<String> result = new ArrayList<>();
        String[] splited = main.split(" ");
        for (int i = 0; i < splited.length; i++) {
            for (String string : operateur) {
                if (splited[i].equalsIgnoreCase(string)) {
                    result.add(splited[i - 1]);
                }
            }
        }
        return result;
    }

    public static ArrayList<String> getUnionIntersection(String main) {
        ArrayList<String> result = new ArrayList<>();
        String[] splited = main.split(" ");
        for (String string : splited) {
            if (string.equalsIgnoreCase("and") || string.equalsIgnoreCase("or")) {
                result.add(string);
            }
        }
        return result;
    }

    public static boolean containsWHERE(String main) {
        String[] splited = main.split(" ");
        for (String string : splited) {
            if (!string.equalsIgnoreCase("WHERE")) {
                return true;
            }
        }
        return false;
    }

    String createTable = "CREATE TABLE Voiture ( marque String 10 , model String 10 , Poids integer 10)";

    public static void createTable(DataBase db, String main) throws Exception {
        if (!main.startsWith("CREATE TABLE")) {
            throw new IllegalArgumentException("La commande doit commencer par 'CREATE TABLE'");
        }
        if (!main.contains("(") || !main.contains(")")) {
            throw new IllegalArgumentException("La commande doit contenir des parenthèses pour les colonnes");
        }

        String[] splited = main.split(" ");
        ArrayList<Attributs> attributs = new ArrayList<>();
        try {
            for (int i = 4; i < splited.length; i += 4) {
                if (splited[i].equals(")"))
                    break;
                String columnName = splited[i].replace(")", "");
                String columnType = splited[i + 1];
                int columnSize = Integer.parseInt(splited[i + 2]);
                attributs.add(new Attributs(columnName, new Domaine(columnType, columnSize)));
            }
        } catch (Exception e) {
            System.out.println("Erreur lors de l'analyse de la commande : " + e.getMessage());
            throw e;
        }

        for (Attributs attribut : attributs) {
            System.out.println(attribut.getAttributName());
        }
        db.createTable(splited[2], attributs);
        new ObjectOutputStream(new FileOutputStream((String) ConfigReader.readConfig()[2])).writeObject(db);
    }

    public static int indexOfValue(String main) {
        String[] splited = main.split(" ");
        int i = 0;
        int result = 0;
        while (i < splited.length) {
            if (splited[i].equalsIgnoreCase("value")) {
                result = i;
            }
            i++;
        }
        return result;
    }

    public static ArrayList<Object> insideValue(String main) {
        int index = indexOfValue(main);
        String[] splitted = main.split(" ");
        ArrayList<Object> result = new ArrayList<>();
        for (int i = index + 1; i < splitted.length - 1; i++) {
            String value = splitted[i];
            if (!value.equals("(") && !value.equals(",") && !value.equals(")")) {
                result.add(value);
            }
        }
        return result;
    }

    public static void insertInto(DataBase db, String main) throws Exception {
        Entite entity = null;
        String[] splitted = main.split(" ");

        for (Entite entite : db.getTables()) {
            if (entite.getNomEntite().equals(splitted[2])) {
                entity = entite;
                break;
            }
        }

        if (entity == null) {
            throw new Exception("La table '" + splitted[2] + "' n'existe pas dans la base de données.");
        }

        ArrayList<Object> values = insideValue(main);

        if (values.size() != entity.getAttributs().size()) {
            throw new Exception("Le nombre de valeurs ne correspond pas au nombre d'attributs.");
        }

        for (int i = 0; i < entity.getAttributs().size(); i++) {
            Attributs attribut = entity.getAttributs().get(i);
            String valeurString = values.get(i).toString();
            Object valeur;

            try {
                if (attribut.getDomaine().getTypeAttribut().equals(Integer.class)
                        || attribut.getDomaine().getTypeAttribut().equals(int.class)) {
                    valeur = Integer.parseInt(valeurString);
                } else if (attribut.getDomaine().getTypeAttribut().equals(Double.class)) {
                    valeur = Double.parseDouble(valeurString);
                } else {
                    valeur = valeurString;
                }
            } catch (NumberFormatException e) {
                throw new Exception("Erreur lors de la conversion de la valeur '" + valeurString + "' pour l'attribut '"
                        + attribut.getAttributName() + "'.");
            }

            attribut.insertNuplets(valeur);
        }

        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream((String) ConfigReader.readConfig()[2]))) {
            oos.writeObject(db);
        }
    }

    public static ArrayList<Object> describe(DataBase db, String request) throws Exception {
        ArrayList<Object> result = new ArrayList<>();
        String[] splited = request.split(" ");
        Entite entite = db.getEntiteByNom(splited[1]);
        for (Attributs att : entite.getAttributs()) {
            result.add(att.getAttributName() + "||" + att.getDomaine().getTypeAttribut() + "||"
                    + att.getDomaine().getSize());
        }
        return result;
    }

    public static ArrayList<Object> processRequest(DataBase db, String request) throws SQLException {
        ArrayList<Object> result = new ArrayList<>();

        try {
            if (request.toUpperCase().startsWith("SELECT")) {
                try {
                    result = processSelect(db, request);
                } catch (Exception e) {
                    result.add("error : "+e.getMessage());
                }
            } else if (request.toUpperCase().startsWith("CREATE")) {
                try {
                    createTable(db, request);
                    result.add("Table créée avec succès");
                } catch (Exception e) {
                    result.add(e.getMessage());
                }
            } else if (request.toUpperCase().startsWith("INSERT")) {
                try {
                    insertInto(db, request);
                    result.add("Ligne insérée avec succès");
                } catch (Exception e) {
                    result.add(e.getMessage());
                }
            } else if (request.equalsIgnoreCase("SHOW TABLE")) {
                try {
                    for (Entite table : db.getTables()) {
                        result.add(table.getNomEntite());
                    }
                } catch (Exception e) {
                    result.add(e.getMessage());
                }
            } else if (request.toUpperCase().startsWith("DESCRIBE")) {
                try {
                    result = describe(db, request);
                } catch (Exception e) {
                    result.add(e.getMessage());
                }
            } else if (request.startsWith("UPDATE")) {
                DotheUpdate(db, request);
                result.add("modification avec succes");
            } else if (request.startsWith("DELETE")) {
                doTheDelete(db, request);
                result.add("ligne supprimé avec succes");
            } else if (request.startsWith("SUM")) {
                Number n = doTheSum(db, request);
                result.add(n);

            } else if (request.startsWith("AVG")) {
                Number n = doTheAvg(db, request);
                result.add(n);
            }else if (request.startsWith("DROP")) {
                doTheDropTable(db, request);
                result.add("table supprimé");
            } 
            else {
                throw new SQLException("Requête invalide ou non supportée : " + request);
            }
        } catch (Exception e) {
            throw new SQLException("Erreur lors du traitement de la requête : " + request, e);
        }

        return result;
    }

    public static Object parseValue(String value) {
        try {
            return Integer.parseInt(value); // Essayez comme Integer
        } catch (NumberFormatException e1) {
            try {
                return Double.parseDouble(value); // Essayez comme Double
            } catch (NumberFormatException e2) {
                return value; // Sinon, considérez comme String
            }
        }
    }
    

    private static ArrayList<Object> processSelect(DataBase db, String request) throws Exception {
        ArrayList<Object> result = new ArrayList<>();
        ArrayList<ArrayList<Object>> ensembleSelection = new ArrayList<>();

        String entity = getEntite(request);
        ArrayList<String> colonne = getColonne(request);
        Entite enityByDb = db.getEntiteByNom(entity);
        Entite projected = enityByDb.projection(colonne);

        ArrayList<String> valeurs = getValeur(request);
        ArrayList<Object> valeur = new ArrayList<>();
        for (String v : getValeur(request)) {
            valeur.add(parseValue(v));
        }


        ArrayList<String> operateur = getOperateur(request);
        ArrayList<String> colonneDesConditions = getColonneDesConditions(request);
        ArrayList<String> str = new ArrayList<>();
        String[] string = request.split(" ");
        for (String iterable_element : string) {
            str.add(iterable_element);
        }
        if (str.contains("WHERE")) {
            if (operateur.size() > 1) {
                for (int i = 0; i < operateur.size(); i++) {
                    try {
                        ensembleSelection.add(projected.selection(enityByDb, null, (valeur.get(i)), operateur.get(i)));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                String unionIntersectionType = getUnionIntersection(request).get(0).toLowerCase();
                switch (unionIntersectionType) {
                    case "and":
                        result = Operateur.intersection(ensembleSelection.get(0), ensembleSelection.get(1));
                        break;
                    case "or":
                        result = Operateur.union(ensembleSelection.get(0), ensembleSelection.get(1));
                        break;
                    
                }
            } else {
                try {
                    result = projected.selection(enityByDb, colonneDesConditions.get(0), (valeur.get(0)), operateur.get(0));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        } else {
            System.out.println("holaaa");
            result = projected.selectionPur(projected);
        }

        return result;
    }

    
public static ArrayList<String> lookDropTable(String script) {
    String[] splited = script.split(" ");
    ArrayList<String> result = new ArrayList<>();
    int taille = splited.length;

    if (taille == 3
            && splited[0].equalsIgnoreCase("DROP")
            && splited[1].equalsIgnoreCase("TABLE")) {

        result.add(splited[2]); // Nom de la table
    }

    return result;
}

public static void doTheDropTable(DataBase db, String requete) throws Exception {
    ArrayList<String> toDrop = lookDropTable(requete);

    if (toDrop.isEmpty()) {
        throw new Exception("Requête invalide : La syntaxe doit être 'DROP TABLE <NomTable>'.");
    }

    String nomTable = toDrop.get(0);

    try {
        db.dropTable(nomTable);
        System.out.println("Table \"" + nomTable + "\" supprimée avec succès.");
    } catch (Exception e) {
        throw new Exception("Erreur lors de la suppression de la table : " + e.getMessage());
    }

    // Sauvegarde de la base de données
    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("RandyDataBases.randy"))) {
        oos.writeObject(db);
    }
}


    public static ArrayList<String> lookUpdate(String script) {
        String[] splited = script.split(" ");
        ArrayList<String> result = new ArrayList<>();
        int taille = splited.length;

        for (int i = 0; i < taille; i++) {
            if (splited[i].equalsIgnoreCase("UPDATE")) {
                result.add(splited[i + 1]);
            }

            if (splited[i].equalsIgnoreCase("SET")) {
                String[] assignment = splited[i + 1].split("=");
                if (assignment.length == 2) {
                    result.add(assignment[0].trim());
                    result.add(assignment[1].trim());
                }
            }

            if (splited[i].equalsIgnoreCase("WHERE")) {
                StringBuilder conditionBuilder = new StringBuilder();
                for (int j = i + 1; j < splited.length; j++) {
                    conditionBuilder.append(splited[j]).append(" ");
                }
                String condition = conditionBuilder.toString().trim();

                String[] operators = { "!==", "==", "<=", ">=", "!=", "=", "<", ">" };
                String detectedOperator = null;

                for (String op : operators) {
                    if (condition.contains(op)) {
                        detectedOperator = op;
                        break;
                    }
                }

                if (detectedOperator != null) {
                    String[] attributes = condition.split(java.util.regex.Pattern.quote(detectedOperator));
                    if (attributes.length == 2) {
                        result.add(attributes[0].trim());
                        result.add(detectedOperator);
                        result.add(attributes[1].trim());
                    }
                } else {
                    throw new IllegalArgumentException("Aucun opérateur valide trouvé dans la condition.");
                }
            }

        }
        return result;
    }

    public static void DotheUpdate(DataBase db, String request) throws Exception {
        ArrayList<String> toupdate = ProcessRequest.lookUpdate(request);
        Entite e = db.getEntiteByNom(toupdate.get(0));
        String attributModif = toupdate.get(1);
        String conditionAttribut = toupdate.get(3);
        Object valueEdit = (Object) toupdate.get(2);
        String op = toupdate.get(4);
        Object valueCondtion = toupdate.get(5);
        e.updateEntite(attributModif, valueEdit, conditionAttribut, op, valueCondtion);
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("RandyDataBases.randy"))) {
            oos.writeObject(db);
        }
    }

    public static ArrayList<String> lookDelete(String script) {
        String[] splited = script.split(" ");
        ArrayList<String> result = new ArrayList<>();
        int taille = splited.length;

        for (int i = 0; i < taille; i++) {
            // Récupération du nom de la table après "DELETE FROM"
            if (splited[i].equalsIgnoreCase("DELETE") && i + 1 < taille && splited[i + 1].equalsIgnoreCase("FROM")) {
                result.add(splited[i + 2]); // Nom de la table
            }

            // Extraction de la condition après "WHERE"
            if (splited[i].equalsIgnoreCase("WHERE")) {
                StringBuilder conditionBuilder = new StringBuilder();
                for (int j = i + 1; j < taille; j++) {
                    conditionBuilder.append(splited[j]).append(" ");
                }
                String condition = conditionBuilder.toString().trim();

                // Détection dynamique de l'opérateur
                String[] operators = { "!==", "==", "<=", ">=", "!=", "=", "<", ">" };
                String detectedOperator = null;

                // Rechercher l'opérateur dans la condition
                for (String op : operators) {
                    if (condition.contains(op)) {
                        detectedOperator = op;
                        break;
                    }
                }

                if (detectedOperator != null) {
                    // Séparer la condition en attribut et valeur avec l'opérateur trouvé
                    String[] attributes = condition.split(java.util.regex.Pattern.quote(detectedOperator));
                    if (attributes.length == 2) {
                        result.add(attributes[0].trim()); // Colonne de la condition
                        result.add(detectedOperator); // Opérateur
                        result.add(attributes[1].trim()); // Valeur de la condition
                    }
                } else {
                    throw new IllegalArgumentException("Aucun opérateur valide trouvé dans la condition.");
                }
            }
        }
        return result;
    }

    public static void doTheDelete(DataBase db, String requete) throws Exception {
        ArrayList<String> toDelete = ProcessRequest.lookDelete(requete);
        Entite e = db.getEntiteByNom(toDelete.get(0));
        String attributDelete = toDelete.get(1);
        Object valueCondition = (Object) toDelete.get(3);
        String op = toDelete.get(2);
        e.deleteSome(attributDelete, op, valueCondition);
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("RandyDataBases.randy"))) {
            oos.writeObject(db);
        }
    }

    public static ArrayList<String> lookSum(String script) {
        String[] splited = script.split(" ");
        ArrayList<String> result = new ArrayList<>();
        int taille = splited.length;

        if (taille == 4
                && splited[0].equalsIgnoreCase("SUM")
                && splited[2].equalsIgnoreCase("FROM")) {
            result.add(splited[1]); // Nom de l'attribut
            result.add(splited[3]); // Nom de l'entité
        }

        return result;
    }

    public static ArrayList<String> lookAvg(String script) {
        String[] splited = script.split(" ");
        ArrayList<String> result = new ArrayList<>();
        int taille = splited.length;

        if (taille == 4
                && splited[0].equalsIgnoreCase("AVG")
                && splited[2].equalsIgnoreCase("FROM")) {
            result.add(splited[1]); // Nom de l'attribut
            result.add(splited[3]); // Nom de l'entité
        }

        return result;
    }

    public static Number doTheSum(DataBase db, String requete) throws Exception {
        ArrayList<String> toSum = lookSum(requete);

        if (toSum.isEmpty()) {
            throw new Exception("Requête invalide : La syntaxe doit être 'SUM <NomAttribut> FROM <NomEntite>'.");
        }

        String nomAttribut = toSum.get(0);
        String nomEntite = toSum.get(1);

        Entite e = db.getEntiteByNom(nomEntite);
        if (e == null) {
            throw new Exception("Entité \"" + nomEntite + "\" introuvable dans la base de données.");
        }

        Number sum = e.sum(nomAttribut);

        // Sauvegarde de la base de données
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("RandyDataBases.randy"))) {
            oos.writeObject(db);
        }

        return sum;
    }

    public static Number doTheAvg(DataBase db, String requete) throws Exception {
        ArrayList<String> toAvg = lookAvg(requete);

        if (toAvg.isEmpty()) {
            throw new Exception("Requête invalide : La syntaxe doit être 'AVG <NomAttribut> FROM <NomEntite>'.");
        }

        String nomAttribut = toAvg.get(0);
        String nomEntite = toAvg.get(1);

        Entite e = db.getEntiteByNom(nomEntite);
        if (e == null) {
            throw new Exception("Entité \"" + nomEntite + "\" introuvable dans la base de données.");
        }

        Number avg = e.avg(nomAttribut);

        // Sauvegarde de la base de données
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("RandyDataBases.randy"))) {
            oos.writeObject(db);
        }

        return avg;
    }

    public static void main(String[] args) throws Exception {
        DataBase db = (DataBase) new ObjectInputStream(new FileInputStream("RandyDataBases.randy")).readObject();
        ArrayList<Object> a = processRequest(db, "SELECT Nom / Agee FROM Client WHERE Agee > 10");
        System.out.println(a);
    }

}
