package Net;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public final class ConfigReader {

    public static Object[] readConfig() {
        String host = null;
        int port = 0;
        String database = null;

        try (BufferedReader br = new BufferedReader(new FileReader("DB_conf.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(":", 2);
                if (parts.length < 2) continue;

                String key = parts[0].trim();
                String value = parts[1].trim();

                switch (key) {
                    case "HOST":
                        host = value;
                        break;
                    case "PORT":
                        port = Integer.parseInt(value);
                        break;
                    case "STORAGE":
                        database = value;
                        break;
                }
            }
        } catch (IOException e) {
            System.out.println("Erreur de lecture du fichier : " + e.getMessage());
        }

        return new Object[] { host, port, database };
    }

    public static void main(String[] args) {
        Object[] o = readConfig();
        System.out.println("HOST : "+o[0]);
        System.out.println("PORT : "+o[1]);
        System.out.println("Data : "+o[2]);
    }
}
