package RandyDataBases;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.AEADBadTagException;

import Net.DatabaseServer;

public class Main {

    public static void main(String[] args) {
        DataBase db = new DataBase("Voiture", null);
        
        ArrayList<Entite> tables = new ArrayList<>();
    
        // Création de l'entité Voiture
        Entite voiture = new Entite("Voiture", null);

        
        Attributs attV1 = new Attributs("Marque", new Domaine(String.class, 30));
        Attributs attV2 = new Attributs("Poids", new Domaine(Double.class, 30));
        Attributs attV3 = new Attributs("About", new Domaine(Double.class, 30));
        voiture.setAttributs(new ArrayList<>(List.of(attV1,attV2,attV3)));


        ArrayList<String> str = new ArrayList<>(List.of("Marque","Poids","About"));
        ArrayList<Domaine> domaines = new ArrayList<>(List.of(new Domaine(String.class, 30),new Domaine(Double.class, 30),new Domaine(Double.class, 30)));

        
        // Insertion des données pour Voiture
        try {
            attV1.insertNuplets("Toyota");
            attV2.insertNuplets(1200.0);
            attV3.insertNuplets(1200.0);

            attV1.insertNuplets("Ford");
            attV2.insertNuplets(1500.0);
            attV3.insertNuplets(1200.0);
            
            attV1.insertNuplets("Honda");
            attV2.insertNuplets(1100.0); 
            attV3.insertNuplets(1200.0);

            attV1.insertNuplets("Peugeot");
            attV2.insertNuplets(1300.0);
            attV3.insertNuplets(1200.0);


        } catch (Exception e) {
            System.out.println("Erreur lors de l'insertion dans Voiture : " + e.getMessage());
        }
        
        // Création de l'entité Chauffeur
        Entite chauffeur = new Entite("Chauffeur", null);
        Attributs attCh1 = new Attributs("Nom", new Domaine(String.class, 30));
        Attributs attCh2 = new Attributs("Age", new Domaine(Integer.class, 3));
        Attributs attCh3 = new Attributs("Experience", new Domaine(Integer.class, 3));
        Object[] attribut4 = {2, "Garantie incluse", "Assistance 24/7", 1, "rouge",true};

        Attributs attCh4 = new Attributs("Information", new Domaine(attribut4,0)); 
        Attributs attCh5 = new Attributs("Client", new Domaine(String.class,30)); 
        chauffeur.setAttributs(new ArrayList<>(List.of(attCh1, attCh2, attCh3,attCh4,attCh5)));


        // Insertion des données pour Chauffeur
        try {
            attCh1.insertNuplets("Alice");
            attCh2.insertNuplets(30);
            attCh3.insertNuplets(5);
            attCh4.insertNuplets("rouge");
            attCh5.insertNuplets("Charles Dupont");

            attCh1.insertNuplets("Ford");
            attCh2.insertNuplets(40);
            attCh3.insertNuplets(10);
            attCh4.insertNuplets(true);
            attCh5.insertNuplets("Charles Dupont");

            attCh1.insertNuplets("Charlie");
            attCh2.insertNuplets(25);
            attCh3.insertNuplets(22);
            attCh4.insertNuplets(true);
            attCh5.insertNuplets("Charles Dupont");

            attCh1.insertNuplets("Randy");
            attCh2.insertNuplets(35);
            attCh3.insertNuplets(12);
            attCh4.insertNuplets(2);
            attCh5.insertNuplets("Charles Dupont");
        } catch (Exception e) {
            System.out.println("Erreur lors de l'insertion dans Chauffeur : " + e.getMessage());
        }

        // Création de l'entité Client
        Entite client = new Entite("Client", null);
        Attributs attCl1 = new Attributs("Nom", new Domaine(String.class, 30));
        Attributs attCl2 = new Attributs("Adresse", new Domaine(String.class, 30));
        Attributs attCl3 = new Attributs("Agee", new Domaine(Integer.class, 3));
        client.setAttributs(new ArrayList<>(List.of(attCl1, attCl2 ,attCl3)));

        // Insertion des données pour Client
        try {
            attCl1.insertNuplets("Charles Dupont");
            attCl2.insertNuplets("123 Rue Exemple");
            attCl3.insertNuplets(25);

            attCl1.insertNuplets("Diane Martin");
            attCl2.insertNuplets("456 Avenue Lumière");
            attCl3.insertNuplets(28);

            attCl1.insertNuplets("Alice Lefevre");
            attCl2.insertNuplets("789 Boulevard du Parc");
            attCl3.insertNuplets(19);

            attCl1.insertNuplets("Bob Bernard");
            attCl2.insertNuplets("321 Route de la Mer");
            attCl3.insertNuplets(45);
        } catch (Exception e) {
            System.out.println("Erreur lors de l'insertion : " + e.getMessage());
        }

        tables.add(voiture);
        tables.add(chauffeur);
        tables.add(client);
        db.setTables(tables);

        try {
            for (Object obj : chauffeur.selectionPur(chauffeur)) {
                System.out.println("huhu"+obj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            new ObjectOutputStream(new FileOutputStream("RandyDataBases.randy")).writeObject(db);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // try {
        //     DataBase db = (DataBase) new ObjectInputStream(new FileInputStream("RandyDataBases.randy")).readObject();
            
        //     ArrayList<Object> dbs = ProcessRequest.processRequest(db,"SELECT Nom / Agee FROM Client");
        //     for (Object object : dbs) {
        //         if( object instanceof ArrayList<?>){
        //             ArrayList<Object> o = (ArrayList<Object>) object;
        //             System.out.println(o.get(1));
        //         }
        //     }
        // } catch (Exception e) {
        //     e.printStackTrace();
        // }
        // System.out.println("--------------------------");
        // try {
        //     Entite projectEntite = chauffeur.projection(new ArrayList<>(List.of("Age","Nom")));
        //     ArrayList<Object> chauff = projectEntite.selection(chauffeur,"Age", 0,">=");
        //     ArrayList<Object> chauff2 = projectEntite.selection(chauffeur,"Age", 30,"<=");
        //     ArrayList<Object> intersection = Operateur.intersection(chauff, chauff2);
        //     for (Object obj : intersection) {
        //         System.out.println("Nom"+ obj);            
        //     }

            
        // } catch (Exception e) {
        //     e.printStackTrace(); 
        // }
        // try {
        //     ArrayList<ArrayList<Object>> cartesien = client.produitCartesien(chauffeur);
        //     for (ArrayList<Object> o : cartesien) {
        //         // System.out.println(o);
        //     }
        // } catch (Exception e) {
        //     e.printStackTrace();
        // }
        // System.out.println("//////////////////");
        // try {
        //     ArrayList<Object> join = Operateur.jointure(client,chauffeur,"Agee","Age",">=");
        //     for (Object iterable_element : join) {
        //         System.out.println(iterable_element);
        //     }
        // } catch (Exception e) {
        //     e.printStackTrace();
        // }
    }
}