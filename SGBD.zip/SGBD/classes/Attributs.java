package RandyDataBases;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Arrays;

public class Attributs implements Serializable{
    
    private String attributName;
    private ArrayList<Nuplets> colonne;

    public String getAttributName() {
        return attributName;
    }

    public void setAttributName(String attributName) {
        this.attributName = attributName;
    }

    private Domaine domaine;

    public Domaine getDomaine() {
        return domaine;
    }

    public void setDomaine(Domaine domaine) {
        this.domaine = domaine;
    }

    public Attributs(String attributName, Domaine domaine) {
        this.attributName = attributName;
        this.domaine = domaine;
        this.colonne = new ArrayList<>(); 
        
    }

    public ArrayList<Nuplets> getColonne() {
        return colonne;
    }

    public void setColonne(ArrayList<Nuplets> colonne) {
        this.colonne = colonne;
    }

    public void insertNuplets(Object valeur) throws Exception {
        Object typeAttribut = this.getDomaine().getTypeAttribut();
    
        if (typeAttribut instanceof Class<?>) {
            if (!((Class<?>) typeAttribut).isInstance(valeur)) {
                throw new Exception("La valeur doit être un " + ((Class<?>) typeAttribut).getSimpleName());
            }
        }
        if (typeAttribut.getClass().isArray()) {
            Object[] domainArray = (Object[]) typeAttribut;
            if (!Arrays.asList(domainArray).contains(valeur)) {
                throw new Exception("La valeur " + valeur + " n'est pas dans le domaine ");
            }
        } 
        else if (typeAttribut instanceof Collection<?>) {
            Collection<?> domainCollection = (Collection<?>) typeAttribut;
            if (!domainCollection.contains(valeur)) {
                throw new Exception("La valeur " + valeur + " n'est pas dans le domaine");
            }
        }
        if (valeur instanceof String && !typeAttribut.getClass().isArray() && !(typeAttribut instanceof Collection<?>)) {
            String strValue = (String) valeur;
            if (strValue.length() > this.getDomaine().getSize()) {
                throw new Exception("Valeur trop grande, maximum : " + this.getDomaine().getSize());
            }
        }
        else if (valeur instanceof Number && !typeAttribut.getClass().isArray() && !(typeAttribut instanceof Collection<?>)) {
            Number nbr = (Number) valeur;
            if (nbr.toString().length() > this.getDomaine().getSize()) {
                throw new Exception("Le nombre " + valeur + " est trop grand, maximum : " + this.getDomaine().getSize());
            }
        }
    
        colonne.add(new Nuplets(valeur));
    }

    
    public ArrayList<Nuplets> getConcernedConditionNumber(String operateur, Number valeur) throws Exception {
        ArrayList<Nuplets> allValeur = this.getColonne();
        ArrayList<Nuplets> concernedValues = new ArrayList<>();

        for (Nuplets nuplet : allValeur) {
            Number nupletValue = (Number) nuplet.getValeur(); // Assurez-vous que Nuplets contient une méthode getValue() pour obtenir la valeur

            boolean conditionMet = false;

            switch (operateur) {
                case "<":
                    conditionMet = nupletValue.doubleValue() < valeur.doubleValue();
                    break;
                case "<=":
                    conditionMet = nupletValue.doubleValue() <= valeur.doubleValue();
                    break;
                case ">":
                    conditionMet = nupletValue.doubleValue() > valeur.doubleValue();
                    break;
                case ">=":
                    conditionMet = nupletValue.doubleValue() >= valeur.doubleValue();
                    break;
                case "==":
                    conditionMet = nupletValue.doubleValue() == valeur.doubleValue();
                    break;
                case "!==":
                    conditionMet = nupletValue.doubleValue() != valeur.doubleValue();
                    break;
                default:
                    throw new Exception("Opérateur non reconnu : " + operateur);
            }

            if (conditionMet) {
                concernedValues.add(nuplet);
            }
        }

        return concernedValues;
    }

    public ArrayList<Nuplets> getConcernedConditionString(String operateur, String valeur) throws Exception {
        ArrayList<Nuplets> allValeur = this.getColonne();
        ArrayList<Nuplets> concernedValues = new ArrayList<>();

        for (Nuplets nuplet : allValeur) {
            String nupletValue = (String) nuplet.getValeur();

            boolean conditionMet = false;

            switch (operateur) {
                case "=":
                    conditionMet = nupletValue.equals(valeur);
                    break;
                case "!=":
                    conditionMet = !nupletValue.equals(valeur);
                    break;
                default:
                    throw new Exception("Opérateur non reconnu : " + operateur);
            }

            if (conditionMet) {
                concernedValues.add(nuplet);
            }
        }

        return concernedValues;
    }

        
    
}
