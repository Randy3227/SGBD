package RandyDataBases;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;


public class Entite implements Serializable {
    private String nomEntite;
    private ArrayList<Attributs> attributs;

    public Entite(String nomEntite, ArrayList<Attributs> attributs) {

        this.nomEntite = nomEntite;
        this.attributs = attributs;
    }

    public Entite() {
    }

    public String getNomEntite() {
        return nomEntite;
    }

    public void setNomEntite(String nom) {
        nomEntite = nom;
    }

    public ArrayList<Attributs> getAttributs() {
        return attributs;
    }

    public void setAttributs(ArrayList<Attributs> att) {
        attributs = att;
    }
    public Attributs geAttributsByNom(String attribut)throws Exception{
        Attributs result = null;
        for (Attributs attr : this.attributs) {
            if(attr.getAttributName().equalsIgnoreCase(attribut))
                result = attr;
        }
        return result;
    }

    public void addAttribut(String attributName, Object domaine, int size) throws Exception {
        if (!(domaine.getClass().isInstance(Integer.class)
                && domaine.getClass().isInstance(String.class)
                && domaine.getClass().isInstance(Number.class)
                && domaine.getClass().isInstance(Date.class)
                && domaine.getClass().isInstance(Character.class)
                && domaine.getClass().isInstance(Double.class)
                && domaine.getClass().isArray()
                && domaine instanceof Collection<?>))
            throw new Exception("Invalide type d'attribut " + domaine);
        else
            attributs.add(new Attributs(attributName, new Domaine(domaine, size)));
    }

    public void removeAttribut(String attributName) throws Exception {
        for (Attributs att : attributs) {
            if (att.getAttributName().equalsIgnoreCase(attributName))
                attributs.remove(att);
            else
                throw new Exception("Aucun attribut " + attributName);
        }
    }

    public Entite projection(ArrayList<String> colonneRestant) throws Exception {
        Entite result = null;
        ArrayList<Attributs> reste = new ArrayList<>();
        for (Attributs att : this.getAttributs()) {
            if (colonneRestant.contains(att.getAttributName())) {
                reste.add(att);
            }
        }
        result = new Entite(this.getNomEntite(), reste);
        return result;
    }

    public Attributs checkIfAttributExist(Entite entite, String attributs) {
        Attributs exist = null;
        for (Attributs att : entite.getAttributs()) {
            if (att.getAttributName().equals(attributs))
                exist = att;
        }
        return exist;
    }

    public ArrayList<Integer> index(Entite entite, String attributs, Object valeur, String operation) throws Exception {
        ArrayList<Integer> indices = new ArrayList<>();
        Attributs att = checkIfAttributExist(entite, attributs);
        if (att != null) {
            for (int i = 0; i < att.getColonne().size(); i++) {
                Object colonneForThis = att.getColonne().get(i).getValeur();
                boolean condition = false;
                switch (operation) {
                    case "<":
                        condition = Operateur.compare(colonneForThis, valeur) < 0;
                        break;
                    case "<=":
                        condition = Operateur.compare(colonneForThis, valeur) <= 0;
                        break;
                    case ">":
                        condition = Operateur.compare(colonneForThis, valeur) > 0;
                        break;
                    case ">=":
                        condition = Operateur.compare(colonneForThis, valeur) >= 0;
                        break;
                    case "==":
                    case "=":
                        condition = colonneForThis.equals(valeur);
                        break;
                    case "!=":
                        condition = !colonneForThis.equals(valeur);
                        break;
                    default:
                        throw new Exception("Operation " + operation + " invalide");
                }

                if (condition) {
                    indices.add(i);
                }
            }
            if (indices.isEmpty()) {
                throw new Exception("aucun resultat pour la valeur " + valeur);
            }
        } else if (att == null && attributs != null) {
            throw new Exception("Attribut " + attributs + " invalide");
        } 

        return indices;
    }

    public ArrayList<Object> selectionPur(Entite entite)throws Exception{
        ArrayList<Object> result = new ArrayList<>();
        try {
            for (int i = 0; i < entite.getAttributs().get(0).getColonne().size() ; i++) {
                result.add(Individu.getIndividu(this, i ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public ArrayList<Object> selection(Entite entite, String attributs, Object valeur, String operation)
            throws Exception {
        ArrayList<Object> all = new ArrayList<>();
        try {
            ArrayList<Integer> index = index(entite, attributs, valeur, operation);
            for (Integer i : index) {
                all.add(Individu.getIndividu(this, i));
            }
        } catch (

        Exception e2) {
            e2.printStackTrace();
        }
        return all;
    }

    public ArrayList<ArrayList<Object>> produitCartesien(Entite autre) throws Exception {
        ArrayList<ArrayList<Object>> result = new ArrayList<>();

        try {
            ArrayList<ArrayList<Object>> thisEntite = Individu.selectAll(this);
            ArrayList<ArrayList<Object>> autreEntite = Individu.selectAll(autre);
            for (ArrayList<Object> thisRow : thisEntite) {
                for (ArrayList<Object> entite1 : autreEntite) {
                    ArrayList<Object> entiteCombined = new ArrayList<>();
                    entiteCombined.addAll(thisRow);
                    entiteCombined.addAll(entite1);
                    result.add(entiteCombined);
                }
            }
        } catch (Exception e) {
            System.out.println("Erreur lors de la creation du produit cartesien : " + e.getMessage());
            throw e;
        }

        return result;
    }

    public Attributs getAttributByName(String nomAttribut) {
        for (Attributs att : this.attributs) { // 'attributs' est la liste des attributs de l'entité
            if (att.getAttributName().equals(nomAttribut)) {
                return att;
            }
        }
        return null; // Retourne null si l'attribut n'est pas trouvé
    }
    
    public void updateEntite(String attributModif, Object valeurModif, String conditionAttribut, String operateur, Object valeurCondition) throws Exception {
        // Récupération des attributs
        Attributs attributCondition = getAttributByName(conditionAttribut);
        Attributs attributAModifier = getAttributByName(attributModif);

        if (attributCondition == null) {
            throw new Exception("Attribut " + conditionAttribut + " introuvable dans l'entité.");
        }
        if (attributAModifier == null) {
            throw new Exception("Attribut " + attributModif + " introuvable dans l'entité.");
        }

        // Validation du type de valeur à modifier
        // Récupération et validation du type de l'attribut à modifier
        Object typeAttributModif = attributAModifier.getDomaine().getTypeAttribut();
        Object typeAttributCondition = attributCondition.getDomaine().getTypeAttribut();

        if (typeAttributCondition instanceof Class<?>) {
            Class<?> conditionClass = (Class<?>) typeAttributCondition;

            if (Number.class.isAssignableFrom(conditionClass)) {
                // Traitement pour un type numérique
                if (!(valeurCondition instanceof Number)) {
                    try {
                        valeurCondition = Double.valueOf(valeurCondition.toString());
                    } catch (NumberFormatException e) {
                        throw new Exception("La valeur de la condition doit être un nombre valide.");
                    }
                }
            } else if (conditionClass.equals(String.class)) {
                // Traitement pour un type String
                if (!(valeurCondition instanceof String)) {
                    throw new Exception("La valeur de la condition doit être une chaîne de caractères.");
                }
            } else {
                // Autres types non pris en charge
                throw new Exception("Type de condition non pris en charge : " + conditionClass.getSimpleName());
            }
        }

// Validation du type de la valeur à modifier
        if (typeAttributModif instanceof Class<?>) {
            Class<?> modifClass = (Class<?>) typeAttributModif;

            if (Number.class.isAssignableFrom(modifClass)) {
                if (!(valeurModif instanceof Number)) {
                    try {
                        valeurModif = Double.valueOf(valeurModif.toString());
                    } catch (NumberFormatException e) {
                        throw new Exception("La valeur à modifier doit être un nombre valide.");
                    }
                }
            } else if (modifClass.equals(String.class)) {
                if (!(valeurModif instanceof String)) {
                    throw new Exception("La valeur à modifier doit être une chaîne de caractères.");
                }
            } else {
                throw new Exception("Type de modification non pris en charge : " + modifClass.getSimpleName());
            }
        }

        // Récupération des nuplets concernés
        ArrayList<Nuplets> nupletsCondition = null;

        if (operateur.equalsIgnoreCase("==") || operateur.equalsIgnoreCase("<")
                || operateur.equalsIgnoreCase("<=") || operateur.equalsIgnoreCase(">")
                || operateur.equalsIgnoreCase(">=") || operateur.equalsIgnoreCase("!==")) {
            // Condition numérique

            nupletsCondition = attributCondition.getConcernedConditionNumber(operateur, (Number) valeurCondition);

        } else if (operateur.equalsIgnoreCase("=") || operateur.equalsIgnoreCase("!=")) {
            // Condition textuelle

            nupletsCondition = attributCondition.getConcernedConditionString(operateur, (String) valeurCondition);

        } else {
            throw new Exception("L'opérateur " + operateur + " n'est pas reconnu.");
        }

        // Vérifie que des nuplets ont été trouvés
        if (nupletsCondition == null || nupletsCondition.isEmpty()) {
            System.out.println("Aucune ligne correspondante trouvée pour la condition : " + conditionAttribut + " " + operateur + " " + valeurCondition);
            return;
        }

        // Modification des valeurs dans l'attribut à modifier
        for (Nuplets elemValueConcerned : nupletsCondition) {
            int index = attributCondition.getColonne().indexOf(elemValueConcerned);
            if (index != -1) {
                attributAModifier.getColonne().get(index).setValeur(valeurModif);
            }
        }

        // Log final
        System.out.println("Mise à jour effectuée : " + attributModif + " modifié(e) en " + valeurModif
                + " pour les lignes où " + conditionAttribut + " " + operateur + " " + valeurCondition);
    }

    public void deleteSome(String attributNom, String operateur, Object valeurCondition) throws Exception {
        // Vérifier si l'entité contient des attributs
        if (this.getAttributs() == null || this.getAttributs().isEmpty()) {
            throw new Exception("L'entité ne contient aucun attribut");
        }
    
        // Récupérer l'attribut concerné
        Attributs attributUsed = this.getAttributByName(attributNom);
        if (attributUsed == null) {
            throw new Exception("Attribut " + attributNom + " introuvable");
        }
    
        // Liste des indices des lignes à supprimer
        ArrayList<Integer> indicesToRemove = new ArrayList<>();
        ArrayList<Nuplets> allValeur = attributUsed.getColonne();
    
        // Vérification du type de l'attribut
        Class<?> typeAttribut =(Class<?>) attributUsed.getDomaine().getTypeAttribut();
    
        if (Number.class.isAssignableFrom(typeAttribut)) {
            // Cas où l'attribut est numérique
            Number valeurConditionNum;
            try {
                valeurConditionNum = Double.valueOf(valeurCondition.toString());
            } catch (NumberFormatException e) {
                throw new Exception("La valeur de la condition doit être un nombre valide.");
            }
    
            if (operateur.equalsIgnoreCase("==") || operateur.equalsIgnoreCase("<")
                    || operateur.equalsIgnoreCase("<=") || operateur.equalsIgnoreCase(">")
                    || operateur.equalsIgnoreCase(">=") || operateur.equalsIgnoreCase("!==")) {
    
                ArrayList<Nuplets> valueConcerned = attributUsed.getConcernedConditionNumber(operateur, valeurConditionNum);
                for (Nuplets nuplet : valueConcerned) {
                    int index = allValeur.indexOf(nuplet);
                    if (index >= 0) {
                        indicesToRemove.add(index);
                    }
                }
            } else {
                throw new Exception("Opérateur non reconnu pour un type numérique : " + operateur);
            }
    
        } else if (typeAttribut.equals(String.class)) {
            // Cas où l'attribut est textuel
            if (!(valeurCondition instanceof String)) {
                throw new Exception("La valeur de la condition doit être une chaîne de caractères.");
            }
    
            if (operateur.equalsIgnoreCase("=") || operateur.equalsIgnoreCase("!=")) {
                ArrayList<Nuplets> valueConcerned = attributUsed.getConcernedConditionString(operateur, (String) valeurCondition);
                for (Nuplets nuplet : valueConcerned) {
                    int index = allValeur.indexOf(nuplet);
                    if (index >= 0) {
                        indicesToRemove.add(index);
                    }
                }
            } else {
                throw new Exception("Opérateur non reconnu pour un type textuel : " + operateur);
            }
        } else {
            throw new Exception("Type d'attribut non pris en charge : " + typeAttribut.getSimpleName());
        }
    
        // Supprimer les éléments aux indices correspondants dans tous les attributs
        for (Attributs attribut : this.getAttributs()) {
            ArrayList<Nuplets> colonne = attribut.getColonne();
    
            // Supprimer les éléments en fonction des indices
            for (int i = indicesToRemove.size() - 1; i >= 0; i--) {
                int index = indicesToRemove.get(i);
                if (index < colonne.size()) {
                    colonne.remove(index);
                }
            }
        }
    
        System.err.println("Suppression des lignes correspondant à la condition effectuée.");
    }

    public Number sum(String attributNom) throws Exception {
        Attributs attributUsed = this.getAttributByName(attributNom);
        if (attributUsed == null) {
            throw new Exception("Attribut " + attributNom + " introuvable");
        }

        double sum = 0;
        for (Nuplets nuplet : attributUsed.getColonne()) {
            if (nuplet.getValeur() instanceof Number) {
                sum += ((Number) nuplet.getValeur()).doubleValue();
            } else {
                throw new Exception("L'attribut doit être de type numérique pour calculer la somme");
            }
        }

        return sum;
    }

    public Number avg(String attributNom) throws Exception {
        Attributs attributUsed = this.getAttributByName(attributNom);
        if (attributUsed == null) {
            throw new Exception("Attribut " + attributNom + " introuvable");
        }

        ArrayList<Nuplets> colonne = attributUsed.getColonne();
        if (colonne.isEmpty()) {
            throw new Exception("L'attribut " + attributNom + " ne contient aucune donnée pour calculer la moyenne");
        }

        double sum = 0;
        for (Nuplets nuplet : colonne) {
            if (nuplet.getValeur() instanceof Number) {
                sum += ((Number) nuplet.getValeur()).doubleValue();
            } else {
                throw new Exception("L'attribut doit être de type numérique pour calculer la moyenne");
            }
        }

        return sum / colonne.size();
    }


}