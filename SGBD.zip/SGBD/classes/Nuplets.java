package RandyDataBases;

import java.io.Serializable;

/**
 * Nuplets
 */
public class Nuplets  implements Serializable{

    private Object valeur;
    public Nuplets(Object valeur) {
        this.valeur = valeur;
    }
    public Object getValeur() {
        return valeur;
    }
    public void setValeur(Object valeur) {
        this.valeur = valeur;
    }
    public String toString(){
        return valeur.toString();
    }
}