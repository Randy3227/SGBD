package driver;

import java.sql.*;

public class TestMyOracleDriver {
    public static void main(String[] args) throws Exception{
        try {
            try {
                Class.forName("driver.MyDriver");
            } catch (Exception e) {
                e.printStackTrace();
            }
            Connection conn = DriverManager.getConnection("jdbc:randydb://localhost:3227/rdb");

            System.out.println("Connexion réussie !");

            try (Statement stmt = conn.createStatement();
            ) {
                stmt.executeUpdate("INSERT INTO Personne ( nom , prenom ) value ( 'Robinson' , 'Randy' )");
            } catch (Exception e) {
                e.printStackTrace();
            }
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
