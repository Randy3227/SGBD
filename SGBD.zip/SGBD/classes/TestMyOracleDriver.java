package driver;

import java.sql.*;

public class TestMyOracleDriver {
    public static void main(String[] args) throws Exception{
        try {
            try {
                Class.forName("driver.MyDriver");
            } catch (Exception e) {
                e.printStackTrace();
            }
            Connection conn = DriverManager.getConnection("jdbc:randydb://localhost:3227/rdb");

            System.out.println("Connexion réussie !");

            try (Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select Nom / Agee From Client")) {
                while (rs.next()) {
                    System.out.println(rs.getObject(1) + "tay" + rs.getObject(2));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
