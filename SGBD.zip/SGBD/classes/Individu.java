package RandyDataBases;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Individu
 */
public final class Individu  implements Serializable{

    public static ArrayList<Object> getIndividu(Entite e, int index) throws Exception {
        ArrayList<Object> result = new ArrayList<>();

        if (index < 0 || index >= e.getAttributs().get(0).getColonne().size()) {
            throw new Exception("Index hors limites : " + index);
        }

        for (Attributs att : e.getAttributs()) {
            Nuplets nuplet = att.getColonne().get(index);
            result.add(nuplet.getValeur()); 
        }
        return result;
    }

    public static ArrayList<ArrayList<Object>> selectAll(Entite e) throws Exception {
        ArrayList<ArrayList<Object>> all = new ArrayList<>();
        
        try {
            if (e.getAttributs().isEmpty() || e.getAttributs().get(0).getColonne().isEmpty()) {
                throw new Exception("Aucun attribut ou colonne dans la table "+e.getNomEntite());
            }
            int nombreIndividus = e.getAttributs().get(0).getColonne().size();

            for (int index = 0; index < nombreIndividus; index++) {
                all.add(getIndividu(e, index));
            }
        } catch (Exception e2) {
            System.out.println("Erreur : " + e2.getMessage());
            throw e2; 
        }
        
        return all;
    }
}
