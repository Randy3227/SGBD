package Net;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

import RandyDataBases.*;

public class DatabaseServer {

    private static final String RESET = "\u001B[0m";
    private static final String RED = "\u001B[31m";
    private static final String GREEN = "\u001B[32m";
    private static final String YELLOW = "\u001B[33m";
    private static final String BLUE = "\u001B[34m";
    private static final String CYAN = "\u001B[36m";
    public static void main(String[] args) throws Exception{
        Object[] config = ConfigReader.readConfig();
        int port = 0;
        if(config[1] instanceof Integer){
            port = (int) config[1];
        }
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println(GREEN +"Nouveau client connecté : " + clientSocket.getInetAddress());

                DataBase db = (DataBase) new ObjectInputStream(new FileInputStream((String)ConfigReader.readConfig()[2])).readObject();
                new Thread(() -> {
                        try {
                            handleClient(clientSocket, db);
                            clientSocket.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                }).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void handleClient(Socket clientSocket, DataBase db) throws Exception {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            String request;
            while ((request = in.readLine()) != null) {
                System.out.println(CYAN +"Requête reçue : " + request);
                
                try {
                    ArrayList<Object> response = ProcessRequest.processRequest(db, request);
                    ObjectOutputStream objectOutputStream = new ObjectOutputStream(clientSocket.getOutputStream());
                    objectOutputStream.writeObject(response);
                }catch(Exception e69){
                    ObjectOutputStream objectOutputStream = new ObjectOutputStream(clientSocket.getOutputStream());
                    objectOutputStream.writeObject(e69.getMessage());
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
        }
    }

    
}
